---
name: Submit AI Tool
about: 'Suggest new AI tools for our collection.Help us make our AI tools list the
  best!" '
title: ''
labels: ''
assignees: ''

---

The name of the tool:

The tool category:

A brief description of what the tool does:

A link to the tool's official website:
